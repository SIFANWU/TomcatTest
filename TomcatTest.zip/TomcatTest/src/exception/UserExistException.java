package exception;

public class UserExistException extends Exception {

	public UserExistException() {
		// TODO Auto-generated constructor stub
	}

	public UserExistException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public UserExistException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public UserExistException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public UserExistException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
